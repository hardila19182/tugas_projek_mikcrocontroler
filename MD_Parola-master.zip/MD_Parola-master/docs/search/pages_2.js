var searchData=
[
  ['parola_20library',['Parola Library',['../page_software.html',1,'index']]]
];
