var hierarchy =
[
    [ "MD_PZone", "class_m_d___p_zone.html", null ],
    [ "Print", null, [
      [ "MD_Parola", "class_m_d___parola.html", null ]
    ] ]
];